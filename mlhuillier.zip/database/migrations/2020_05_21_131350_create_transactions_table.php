<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
class CreateTransactionsTable extends Migration {
    public function up() {
        Schema::create('transaction', function (Blueprint $table) {
            $table->increments('id');
            $table->string('kpt_number')->nullable();
            $table->string('coi_number')->nullable();
            $table->string('policy_number')->nullable();
            $table->string('bos_entry_number')->nullable();
            $table->string('ticket_number')->nullable();
            $table->string('insured_name')->nullable();
            $table->string('address')->nullable();
            $table->string('civil_status',10)->nullable();
            $table->string('beneficiary')->nullable();
            $table->string('relationship')->nullable();
            $table->string('dateofbirth')->nullable();
            $table->string('guardian')->nullable();
            $table->string('guardian_dateofbirth')->nullable();
            $table->date('guardian2')->nullable();
            $table->date('guardian_dateofbirth2')->nullable();
            $table->string('child_siblings')->nullable();
            $table->string('child_siblings_dateofbirth')->nullable();
            $table->date('child_siblings2')->nullable();
            $table->date('child_siblings_dateofbirth2')->nullable();
            $table->date('child_siblings3')->nullable();
            $table->date('child_siblings_dateofbirth3')->nullable();
            $table->date('child_siblings4')->nullable();
            $table->date('child_siblings_dateofbirth4')->nullable();
            $table->string('type');
            $table->string('units',10)->nullable();
            $table->date('date_issued')->nullable();
            $table->string('time_issued')->nullable();
            $table->string('status')->nullable();
            $table->string('posted',10)->nullable();
            $table->string('userid_created')->nullable();
            $table->string('userbranch')->nullable();
            $table->string('reason')->nullable();
            $table->string('userid_modified')->nullable();
            $table->timestamps();



        });
    }
    public function down() {
        Schema::dropIfExists('transaction');
    }
}
