<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
class CreateAreasTable extends Migration {
    public function up() {
        Schema::create('areas', function (Blueprint $table) {
            $table->increments('id');
            $table->string('area_name',50)->nullable();
            $table->string('region',50)->nullable();
            $table->string('area_manager',50)->nullable(); 
            $table->string('status',10)->nullable();
            $table->string('userid_created',10)->nullable();
            $table->string('userid_modified',10)->nullable();
            $table->timestamps();
        });
    }
    public function down() {
        Schema::dropIfExists('areas');
    }
}
