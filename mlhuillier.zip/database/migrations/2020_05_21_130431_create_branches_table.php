<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
class CreateBranchesTable extends Migration {
    public function up() {
        Schema::create('branch', function (Blueprint $table) {
            $table->increments('id');
            $table->string('branch_name');
            $table->string('region',100)->nullable();
            $table->string('area',100)->nullable();
            $table->string('city',100)->nullable();
            $table->string('province',100)->nullable();
            $table->string('code',50);
            $table->string('status',10);
            $table->string('userid_created',10);
            $table->string('userid_modified',10);
            $table->timestamps();
        });
    }
    public function down() {
        Schema::dropIfExists('branch');
    }
}
