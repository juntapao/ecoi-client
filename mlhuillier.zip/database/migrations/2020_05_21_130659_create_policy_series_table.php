<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
class CreatePolicySeriesTable extends Migration {
    public function up() {
        Schema::create('policy_series', function (Blueprint $table) {
            $table->increments('id');
            $table->string('coi',50);
            $table->string('series',50);
            $table->string('coi_no', 50);
            $table->string('entry_no', 50)->nullable();
            $table->string('status',50);
            $table->timestamps();
        });
    }
    public function down() {
        Schema::dropIfExists('policy_series');
    }
}
