<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
class CreateCoiAOSTable extends Migration {
    public function up() {
        Schema::create('coi_ao', function (Blueprint $table) {
            $table->increments('id');
            $table->string('kpt_number');
            $table->string('coi_number');
            $table->string('policy_number');
            $table->string('insured_name');
            $table->string('beneficiary');
            $table->date('date_issued');
            $table->string('type');
            $table->string('status');
            $table->string('userid_created');
            $table->string('userbranch');
            $table->string('reason');
            $table->string('userid_modified');
            $table->timestamps();
        });
    }
    public function down() {
        Schema::dropIfExists('coi_ao');
    }
}
