<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
class CreateUserRolesTable extends Migration {
    public function up() {
        Schema::create('user_roles', function (Blueprint $table) {
            $table->increments('id');
            $table->string('role_name');
            $table->string('access');
            $table->string('status');
            $table->string('userid_created');
            $table->string('userid_modified');
            $table->timestamps();
        });
    }
    public function down() {
        Schema::dropIfExists('user_roles');
    }
}
