<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
class AddPriceToTransactionsTable extends Migration {
    public function up() {
        Schema::table('transaction', function(Blueprint $table) {
            $table->decimal('price', 10, 2)->after('units');
        });
    }
    public function down() {
        Schema::table('transaction', function(Blueprint $table) {
            $table->dropColumn('price');
        });
    }
}
