<?php $__env->startSection('search', route('coi_b.search')); ?>
<?php $__env->startSection('header'); ?>
    <div class="row align-items-center py-4">
        <div class="col-7 col-lg-6">
            <h6 class="h2 text-white d-inline-block mb-0">Pinoy Protect Plus</h6>
            <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i class="ni ni-tv-2"></i></a></li>
                <li class="breadcrumb-item">Transaction</li>
                <li class="breadcrumb-item active" aria-current="page">Pinoy Protect Plus</li>
                </ol>
            </nav>
        </div>
        <div class="col-5 col-lg-6 text-right">
            <a href="<?php echo e(route('coi_b.create')); ?>" class="btn btn-sm btn-neutral loading">Add</a>
            <a href="<?php echo e(route('coi_b.index')); ?>" class="btn btn-sm btn-neutral loading">Show All</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="table-responsive">
            <table id="coi_a" class="table table-sm align-items-center table-flush table-hover">
                <thead class="thead-light">
                    <tr>
                        <th>COI Number</th>
                        <th>BOS Entry No</th>
                        <th>Policy Number</th>
                        <th>Insured Name</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody class="list">
                    <?php if(count($transactions) > 0): ?>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr <?php if($transaction->status == 'edited'): ?> class="table-primary" data-toggle="tooltip" data-placement="bottom" title="This record has been modified" <?php endif; ?>>
                                <td><?php echo e($transaction->coi_number); ?></td>
                                <td><?php echo e($transaction->bos_entry_number); ?></td>
                                <td><?php echo e($transaction->policy_number); ?></td>
                                <td><?php echo e($transaction->insured_name); ?></td>
                                <td class="text-center">
                                    <?php if($transaction->posted == NULL): ?>
                                        <a href="<?php echo e(route('coi_b.edit', $transaction->id)); ?>" class="btn btn-sm btn-warning loading" >Edit</a>  
                                        <a href="<?php echo e(route('coi_b.post', $transaction->id)); ?>" onclick="return confirm('Are you sure you want to Post this transaction?')" class="btn btn-sm btn-primary" >Post</a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('coi_b.edit', $transaction->id)); ?>" class="btn btn-sm btn-warning disabled" disabled>Edit</a>  
                                        <a href="<?php echo e(route('coi_b.print', $transaction->id)); ?>" target="_blank" class="btn btn-sm btn-danger" >Print</a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('coi_b.show', $transaction->id)); ?>" class="btn btn-sm btn-success loading" >Show</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="text-center">No transactions found</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer py-4">
            <div class="row">
                <div class="col text-left">Showing <?php echo e($transactions->count()); ?> out of <?php echo e($transactions->total()); ?> record(s)</div>
                <div><?php echo e($transactions->links()); ?></div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp.7.3.27\htdocs\mlhuillier\resources\views/transactions/coi_b/index.blade.php ENDPATH**/ ?>