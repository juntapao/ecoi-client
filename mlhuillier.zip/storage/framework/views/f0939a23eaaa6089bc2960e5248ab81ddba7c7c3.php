<?php if(session('download')): ?>
    <?php if(strpos(url()->current(), 'public') !== false) $public = '../'; else $public = '';  ?>
    <meta http-equiv="refresh" content="2; url=../storage/downloads/<?php echo e(session('download')); ?>">
    <?php echo e(session()->forget('download')); ?>

<?php endif; ?>
<?php /**PATH C:\xampp.7.3.27\htdocs\mlhuillier\resources\views/includes/download.blade.php ENDPATH**/ ?>