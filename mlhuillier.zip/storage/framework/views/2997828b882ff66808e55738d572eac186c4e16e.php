<?php $__env->startSection('search', route('posted.search')); ?>
<?php $__env->startSection('header'); ?>
    <div class="row align-items-center py-4">
        <div class="col-7 col-lg-6">
            <h6 class="h2 text-white d-inline-block mb-0">Posted Transactions</h6>
            <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i class="ni ni-tv-2"></i></a></li>
                <li class="breadcrumb-item">Reports</li>
                <li class="breadcrumb-item active" aria-current="page">Posted Transactions</li>
                </ol>
            </nav>
        </div>
        <div class="col-5 col-lg-6 text-right">
            
            <a href="<?php echo e(route('posted.index')); ?>" class="btn btn-sm btn-neutral loading">Show All</a>
        </div>
    </div>
    <form action="<?php echo e(route('posted.filter')); ?>" method="get">
        <div class="row container">
            <div class="form-group col-12 col-md-4 col-lg-3">
                <strong class="text-secondary">Date From</strong>
                <input type="date" id="date_from" name="date_from" class="form-control <?php if ($errors->has('date_from')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date_from'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(isset($date_from) ? $date_from : old('date_from')); ?>" />
                
                
            </div>
            <div class="form-group col-12 col-md-4 col-lg-3">
                <strong class="text-secondary">Date To</strong>
                <input type="date" id="date_to" name="date_to" class="form-control <?php if ($errors->has('date_to')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date_to'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(isset($date_to) ? $date_to : old('date_to')); ?>" />
                
            </div>
            <div class="col-12 col-md-4 col-lg-3"><br />
                <button type="submit" class="btn btn-success loading">Filter</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="table-responsive">
            <table class="table table-sm align-items-center table-flush table-hover">
                <thead class="thead-light">
                    <tr>
                        <th>COI Number</th>
                        <th>Ticket number</th>
                        <th>Insured Name</th>
                        <th>Transaction Type</th>
                        <th>Branch</th>
                        <th>Date</th>
                        
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody class="list">
                    <?php if(count($transactions) > 0): ?>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($transaction->coi_number); ?></td>
                                <td><?php echo e($transaction->ticket_number); ?></td>
                                <td><?php echo e($transaction->insured_name); ?></td>
                                <td><?php echo e(App\Http\Controllers\CommonController::getTransactionType($transaction->type)); ?></td>
                                <td><?php echo e($transaction->userbranch); ?></td>
                                <td><?php echo e($transaction->date_issued ? Carbon\Carbon::parse($transaction->date_issued)->format('m/d/Y') : null); ?></td>
                                
                                <td class="text-center">
                                    <a href="<?php echo e(route('posted.show', $transaction->id)); ?>" class="btn btn-sm btn-success loading" >Show</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="text-center">No records found</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer py-4">
            <div class="row">
                <div class="col text-left">Showing <?php echo e($transactions->count()); ?> out of <?php echo e($transactions->total()); ?> record(s)</div>
                <div><?php echo e($transactions->links()); ?></div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp.7.3.27\htdocs\mlhuillier\resources\views/reports/posted/index.blade.php ENDPATH**/ ?>