<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo e(config('app.name')); ?></title>
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
    <link rel="stylesheet" href="<?php echo e(asset('argon/vendor/nucleo/css/nucleo.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('argon/vendor/@fortawesome/fontawesome-free/css/all.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('argon/css/argon.css?v=1.2.0')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-select.min.css')); ?>" />
</head>
<body>
    <?php echo $__env->make('includes.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-content" id="panel">
        <?php echo $__env->make('includes.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="header bg-primary pb-6">
            <div class="container-fluid">
                <div class="header-body">
                    <?php echo $__env->make('includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->yieldContent('header'); ?>
                </div>
            </div>
        </div>
        <div class="container-fluid mt--6">
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('includes.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <script src="<?php echo e(asset('argon/vendor/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('argon/vendor/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('argon/vendor/js-cookie/js.cookie.js')); ?>"></script>
    <script src="<?php echo e(asset('argon/vendor/jquery.scrollbar/jquery.scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('argon/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js')); ?>"></script>
    <script src="<?php echo e(asset('argon/vendor/chart.js/dist/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('argon/vendor/chart.js/dist/Chart.extension.js')); ?>"></script>
    <script src="<?php echo e(asset('argon/js/argon.js?v=1.2.0')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-select.min.js')); ?>" defer></script>  
    <?php echo $__env->make('includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('more-scripts'); ?>
</body>
</html>



<?php /**PATH C:\xampp.7.3.27\htdocs\mlhuillier\resources\views/layouts/app.blade.php ENDPATH**/ ?>