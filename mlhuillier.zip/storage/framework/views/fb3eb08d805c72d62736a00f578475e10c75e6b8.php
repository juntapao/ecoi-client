<nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
        <div class="sidenav-header  align-items-center">
            <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>">
                <img src="<?php echo e(asset('images/ml_logo.png')); ?>" class="navbar-brand-img" />
            </a>
        </div>
        <div class="navbar-inner">
            <div class="collapse navbar-collapse" id="sidenav-collapse-main">
                <?php $__currentLoopData = session('parentmenu'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentmenus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <h6 class="navbar-heading p-0 text-muted">
                      <span class="docs-normal"><i class="ni ni-single-copy-04"></i> <?php echo e($parentmenus->label); ?></span>
                  </h6>
                  <ul class="navbar-nav mb-md-3">
                      <?php $__currentLoopData = session('childmenu'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childmenus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($parentmenus->id == $childmenus->parent): ?>
                              <li class="nav-item">
                                  <a class="nav-link loading" href="<?php echo e($childmenus->link); ?>">
                                      
                                      <span class="nav-link-text"><?php echo e($childmenus->label); ?></span>
                                  </a>
                              </li>
                          <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</nav><?php /**PATH C:\xampp.7.3.27\htdocs\mlhuillier\resources\views/includes/sidenav.blade.php ENDPATH**/ ?>