<?php $__env->startSection('search', route('coi_a.search')); ?>
<?php $__env->startSection('header'); ?>
    <div class="row align-items-center py-4">
        <div class="col-7 col-lg-6">
            <h6 class="h2 text-white d-inline-block mb-0">Family Protect Plus</h6>
            <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i class="ni ni-tv-2"></i></a></li>
                <li class="breadcrumb-item">Transaction</li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('coi_a.index')); ?>">Family Protect Plus</a></li>
                <li class="breadcrumb-item active" aria-current="page">Add</li>
                </ol>
            </nav>
        </div>
        <div class="col-5 col-lg-6 text-right">
            <a href="<?php echo e(route('coi_a.index')); ?>" class="btn btn-sm btn-neutral loading">Show All</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <div class="row align-items-center">
            <div class="col-8">
                <h3 class="mb-0">Add a Record</h3>
            </div>
            <div class="col text-right">Issue Date: <?php echo e(date('m/d/Y')); ?></div>
        </div>
    </div>
    <div class="card-header border-0">
        <form method="post" action="<?php echo e(route('coi_a.store')); ?>" novalidate>
            <?php echo csrf_field(); ?>
            <div class="container">
                <div class="row">
                    <div class="form-group col-md-4">
                        <label for="userbranch">ML BRANCH</label>
                        <input type="text" name="userbranch" class="form-control" value="<?php echo e($branch->branch_name); ?>" readonly>
                    </div>
                    
                    <div class="form-group col-md-4">
                        <label for="units">Number of Units</label>
                        <input type="number" name="units" class="form-control <?php if ($errors->has('units')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('units'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Quantity (Maximum of 5)" value="<?php echo e(old('units')); ?>" />
                        <?php if ($errors->has('units')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('units'); ?> <div class="invalid-feedback"><?php echo e($message); ?> </div> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div> 
                <div class="row">
                    <div class="form-group col-md-6">
                        <label for="insured_name">Principal Insured</label>
                        <input type="text" name="insured_name" class="form-control text-uppercase <?php if ($errors->has('insured_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('insured_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Principal Insured" value="<?php echo e(old('insured_name')); ?>" />
                        <?php if ($errors->has('insured_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('insured_name'); ?> <div class="invalid-feedback"><?php echo e($message); ?> </div> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="dateofbirth">Birth Date <small>(18 - 70 yrs. old)</small></label>
                        <input type="date" name="dateofbirth" class="form-control <?php if ($errors->has('dateofbirth')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dateofbirth'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('dateofbirth')); ?>" />
                        <?php if ($errors->has('dateofbirth')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dateofbirth'); ?> <div class="invalid-feedback"><?php echo e($message); ?> </div> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div id="civil_status" class="row">
                    <div class="col-12">
                        <label>Civil Status</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="civil_status" id="single" value="Single" checked />
                            <label class="form-check-label" for="single">Single</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="civil_status" id="married" value="Married" <?php if(old('civil_status') == 'Married'): ?> checked <?php endif; ?> />
                            <label class="form-check-label" for="married">Married</label>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="form-group col-md-6">
                        <label for="guardian">Parents</label>
                        <input type="text" id="guardian" name="guardian" class="form-control text-uppercase <?php if ($errors->has('guardian')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('guardian'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Spouse / Parents" value="<?php echo e(old('guardian')); ?>" />
                        <?php if ($errors->has('guardian')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('guardian'); ?> <div class="invalid-feedback"><?php echo e($message); ?> </div> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="guardian_dateofbirth">Birth Dates <small>(18 - 70 yrs. old)</small></label>
                        <input type="date" id="guardian_dateofbirth" name="guardian_dateofbirth" class="form-control <?php if ($errors->has('guardian_dateofbirth')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('guardian_dateofbirth'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Date of Birth" value="<?php echo e(old('guardian_dateofbirth')); ?>" />
                        <?php if ($errors->has('guardian_dateofbirth')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('guardian_dateofbirth'); ?> <div class="invalid-feedback"><?php echo e($message); ?> </div> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-6">
                        <input type="text" id="guardian2" name="guardian2" class="form-control text-uppercase" placeholder="Spouse / Parents" value="<?php echo e(old('guardian2')); ?>" />
                        <?php if ($errors->has('guardian2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('guardian2'); ?> <div class="invalid-feedback"><?php echo e($message); ?> </div> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group col-md-6">
                        <input type="date" id="guardian_dateofbirth2" name="guardian_dateofbirth2" class="form-control <?php if ($errors->has('guardian_dateofbirth2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('guardian_dateofbirth2'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Date of Birth" value="<?php echo e(old('guardian_dateofbirth2')); ?>" />
                        <?php if ($errors->has('guardian_dateofbirth2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('guardian_dateofbirth2'); ?> <div class="invalid-feedback"><?php echo e($message); ?> </div> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                
                <div class="row">
                    <div class="form-group col-md-6">
                        <label for="child_siblings">Siblings</label>
                        <input type="text" id="child_siblings" name="child_siblings" class="form-control text-uppercase <?php if ($errors->has('child_siblings')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('child_siblings'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Children / Siblings" value="<?php echo e(old('child_siblings')); ?>" />
                        <?php if ($errors->has('child_siblings')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('child_siblings'); ?> <div class="invalid-feedback"><?php echo e($message); ?> </div> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="child_siblings_dateofbirth">Birth Dates <small>(1 - 21 yrs. old)</small></label>
                        <input type="date" id="child_siblings_dateofbirth" name="child_siblings_dateofbirth" class="form-control <?php if ($errors->has('child_siblings_dateofbirth')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('child_siblings_dateofbirth'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Date of Birth" value="<?php echo e(old('child_siblings_dateofbirth')); ?>" />
                        <?php if ($errors->has('child_siblings_dateofbirth')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('child_siblings_dateofbirth'); ?> <div class="invalid-feedback"><?php echo e($message); ?> </div> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-6">
                        <input type="text" id="child_siblings2" name="child_siblings2" class="form-control text-uppercase <?php if ($errors->has('child_siblings2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('child_siblings2'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Children / Siblings" value="<?php echo e(old('child_siblings2')); ?>" />
                        <?php if ($errors->has('child_siblings2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('child_siblings2'); ?> <div class="invalid-feedback"><?php echo e($message); ?> </div> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group col-md-6">
                        <input type="date" id="child_siblings_dateofbirth2" name="child_siblings_dateofbirth2" class="form-control <?php if ($errors->has('child_siblings_dateofbirth2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('child_siblings_dateofbirth2'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Date of Birth" value="<?php echo e(old('child_siblings_dateofbirth2')); ?>" />
                        <?php if ($errors->has('child_siblings_dateofbirth2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('child_siblings_dateofbirth2'); ?> <div class="invalid-feedback"><?php echo e($message); ?> </div> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-6">
                        <input type="text" id="child_siblings3" name="child_siblings3" class="form-control text-uppercase <?php if ($errors->has('child_siblings3')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('child_siblings3'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Children / Siblings" value="<?php echo e(old('child_siblings3')); ?>" />
                        <?php if ($errors->has('child_siblings3')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('child_siblings3'); ?> <div class="invalid-feedback"><?php echo e($message); ?> </div> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group col-md-6">
                        <input type="date" id="child_siblings_dateofbirth3" name="child_siblings_dateofbirth3" class="form-control <?php if ($errors->has('child_siblings_dateofbirth3')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('child_siblings_dateofbirth3'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Date of Birth" value="<?php echo e(old('child_siblings_dateofbirth3')); ?>" />
                        <?php if ($errors->has('child_siblings_dateofbirth3')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('child_siblings_dateofbirth3'); ?> <div class="invalid-feedback"><?php echo e($message); ?> </div> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-6">
                        <input type="text" id="child_siblings4" name="child_siblings4" class="form-control text-uppercase <?php if ($errors->has('child_siblings4')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('child_siblings4'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Children / Siblings" value="<?php echo e(old('child_siblings4')); ?>" />
                        <?php if ($errors->has('child_siblings4')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('child_siblings4'); ?> <div class="invalid-feedback"><?php echo e($message); ?> </div> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group col-md-6">
                        <input type="date" id="child_siblings_dateofbirth4" name="child_siblings_dateofbirth4" class="form-control <?php if ($errors->has('child_siblings_dateofbirth4')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('child_siblings_dateofbirth4'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Date of Birth" value="<?php echo e(old('child_siblings_dateofbirth4')); ?>" />
                        <?php if ($errors->has('child_siblings_dateofbirth4')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('child_siblings_dateofbirth4'); ?> <div class="invalid-feedback"><?php echo e($message); ?> </div> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
            </div>
            
            
            
            <div class="text-right">
                
                <button type="submit" class="btn btn-success loading">Save</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('more-scripts'); ?>
<script defer>
    $('#civil_status input').click(function() {
        if($('#single').is(':checked')) {
            $('#spouse_parents').html('Parents');
            $('#child_siblings').html('Siblings');
        } else if($('#married').is(':checked')) {
            $('#spouse_parents').html('Spouse');
            $('#child_siblings').html('Children');
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp.7.3.27\htdocs\mlhuillier\resources\views/transactions/coi_a/create.blade.php ENDPATH**/ ?>