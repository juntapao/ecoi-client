<?php $__env->startSection('header'); ?>
    <div class="row align-items-center py-4">
        <div class="col-7 col-lg-6">
            <h6 class="h2 text-white d-inline-block mb-0">Detailed Report</h6>
            <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i class="ni ni-tv-2"></i></a></li>
                <li class="breadcrumb-item">Reports</li>
                <li class="breadcrumb-item">Detailed Report</li>
                </ol>
            </nav>
        </div>
        <div class="col-5 col-lg-6 text-right">
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card">
    <div class="card-header">
        <div class="row align-items-center">
            <div class="col-8">
                <h3 class="mb-0">Generate Report</h3>
            </div>
        </div>
    </div>
    <div class="card-header border-0">
        <form method="post" action="<?php echo e(route('detailed.store')); ?>" novalidate>
            <?php echo csrf_field(); ?>
            <div class="container">
                <div class="row">
                    <div class="form-group col-md-4">
                        <strong>Date From</strong>
                        <input type="date" id="date_from" name="date_from" class="form-control <?php if ($errors->has('date_from')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date_from'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('date_from')); ?>" />
                        <?php if ($errors->has('date_from')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date_from'); ?> <div class="invalid-feedback"><?php echo e($message); ?> </div> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group col-md-4">
                        <strong>Date To</strong>
                        <input type="date" id="date_to" name="date_to" class="form-control <?php if ($errors->has('date_to')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date_to'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('date_to')); ?>" />
                        <?php if ($errors->has('date_to')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date_to'); ?> <div class="invalid-feedback"><?php echo e($message); ?> </div> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-12 col-md-4">
                        <label for="region">Region</label>
                        <select class="form-control selectpicker <?php if ($errors->has('region')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('region'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="region" name="region[]" data-live-search="true" multiple>
                            <option disabled>-Select-</option>
                            <?php if(count($regions) > 0): ?>
                                <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($region->id); ?>" <?php if(old('region') == $region->id): ?> selected <?php endif; ?>><?php echo e($region->region_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <?php if ($errors->has('region')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('region'); ?> <div class="invalid-feedback"><?php echo e($message); ?> </div> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group col-12 col-md-4">
                        <label for="area">Area</label>
                        <select class="form-control selectpicker secondary <?php if ($errors->has('area')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('area'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="area" name="area[]" data-live-search="true" multiple>
                            <option disabled>-Select-</option>
                            <?php if(count($areas) > 0): ?>
                                <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($area->id); ?>" <?php if(old('area') == $area->id): ?> selected <?php endif; ?>><?php echo e($area->area_name.' | '.$area->area_manager.' | '.$area->region->region_name.' | '.$area->region->region_manager); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <?php if ($errors->has('area')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('area'); ?> <div class="invalid-feedback"><?php echo e($message); ?> </div> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group col-12 col-md-4">
                        <label for="branch">Branch</label>
                        <select class="form-control selectpicker <?php if ($errors->has('branch')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('branch'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="branch" name="branch[]" data-live-search="true" multiple>
                            <option disabled>-Select-</option>
                            <?php if(count($branches) > 0): ?>
                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($branch->branch_name); ?>" <?php if(old('branch') == $branch->branch_name): ?> selected <?php endif; ?>><?php echo e($branch->branch_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <?php if ($errors->has('branch')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('branch'); ?> <div class="invalid-feedback"><?php echo e($message); ?> </div> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-md-1"></div>
                    <div class="col-12 col-md-11 ml-4">
                        <?php if ($errors->has('product')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('product'); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                        <?php endif; ?>
                        <div class="form-group">
                            <div class="form-check">
                                <input class="form-check-input" name="product[]" type="checkbox" value="A" id="A" <?php if(in_array('A', old('product') ?? [])): ?> checked <?php endif; ?> />
                                <label class="form-check-label" for="A">Family Protect - Plus</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="product[]" type="checkbox" value="AO" id="AO" <?php if(in_array('AO', old('product') ?? [])): ?> checked <?php endif; ?> />
                                <label class="form-check-label" for="AO">KP Protect</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="product[]" type="checkbox" value="B" id="B" <?php if(in_array('B', old('product') ?? [])): ?> checked <?php endif; ?> />
                                <label class="form-check-label" for="B">Pinoy Protect - Plus</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="product[]" type="checkbox" value="D" id="D" <?php if(in_array('D', old('product') ?? [])): ?> checked <?php endif; ?> />
                                <label class="form-check-label" for="D">Family Protect</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="product[]" type="checkbox" value="R" id="R" <?php if(in_array('R', old('product') ?? [])): ?> checked <?php endif; ?> />
                                <label class="form-check-label" for="R">Pawner's Protect</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-right">
                <button type="submit" class="btn btn-success loading">Generate</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp.7.3.27\htdocs\mlhuillier\resources\views/reports/detailed/index.blade.php ENDPATH**/ ?>