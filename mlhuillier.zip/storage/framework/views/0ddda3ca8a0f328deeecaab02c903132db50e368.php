

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php echo e(session()->forget('success')); ?>

<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
    <?php echo e(session()->forget('error')); ?>

<?php endif; ?>






<?php /**PATH C:\xampp.7.3.27\htdocs\mlhuillier\resources\views/includes/message.blade.php ENDPATH**/ ?>