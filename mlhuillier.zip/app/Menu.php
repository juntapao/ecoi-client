<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
class Menu extends Model {
    protected $table = 'menu';
    public $primarykey = 'id';
    public function userrole() {
        return $this->belongsTo('App\UserRole');
    }
}
