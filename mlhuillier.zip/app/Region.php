<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
class Region extends Model {
    protected $table = 'regions';
    public $primarykey = 'id';
    public $timestamps = true;
    public function areas() {
        return $this->hasMany(Area::class);
    }
}
