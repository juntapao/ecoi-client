<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
class Insuran_price extends Model {
    protected $table = 'insuran_prices';
    public $primarykey = 'id';
    public $timestamps = true;
    public function user() {
        return $this->belongsTo('App\User');
    }
    // public function transaction() {
    //     return $this->belongsTo('App\Transaction');
    // }
}
