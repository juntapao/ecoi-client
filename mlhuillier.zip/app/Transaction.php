<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
class Transaction extends Model {
    protected $table = 'transaction';
    public $primarykey = 'id';
    public $timestamps = true;
    protected $dates = [
        'guardian_dateofbirth',
        'guardian_dateofbirth2',
        'child_siblings_dateofbirth',
        'child_siblings_dateofbirth2',
        'child_siblings_dateofbirth3',
        'child_siblings_dateofbirth4',
    ];
    // public function branch() {
    //     return $this->hasMany('App\Branch');
    // }
    public function policyseries() {
        return $this->hasMany('App\PolicySeries');
    }
    public function insuran_price() {
        return $this->hasMany('App\Insuran_price');
    }
    public function user() {
        return $this->belongsTo(User::class, 'userid_created', 'id');
    }
}
