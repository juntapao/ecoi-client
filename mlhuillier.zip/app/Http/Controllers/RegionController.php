<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Region;
class RegionController extends Controller {
    public function index() {
        $regions = Region::where('status', 1)
            ->orderBy('id', 'desc')
            ->paginate(15);
        return view('maintenance.region.index', compact('regions'));
    }
    public function create() {
        return view('maintenance.region.create');
    }
    public function store(Request $request) {
        $request->validate([
            'region_name' => 'required',
            'region_manager' => 'required',
        ]);
        $region = new Region;
        $region->region_name = $request->region_name;
        $region->region_manager = $request->region_manager;
        $region->status = 1;
        $region->userid_created = auth()->user()->id;
        $region->userid_modified = auth()->user()->id;
        if($region->save()) session(['success' => 'Record saved successfully']);
        else session(['error', 'Error on saving the record']);
        return redirect()->route('region.show', $region->id);
    }
    public function show($id) {
        $region = Region::find($id);
        return view('maintenance.region.show', compact('region'));
    }
    public function edit($id) {
        $region = Region::find($id);
        return view('maintenance.region.edit', compact('region'));
    }
    public function update(Request $request, $id) {
        $request->validate([
            'region_name' => 'required',
            'region_manager' => 'required',
        ]);
        $region = Region::find($id);
        $region->region_name = $request->region_name;
        $region->region_manager = $request->region_manager;
        $region->status = 1;
        $region->userid_modified = auth()->user()->id;
        if($region->save()) session(['success' => 'Record saved successfully']);
        else session(['error', 'Error on saving the record']);
        return redirect()->route('region.show', $region->id);
    }
    public function destroy($id) {
        $region = Region::find($id);
        $region->status = 0;
        $region->userid_modified = auth()->user()->id;
        if($region->save()) session(['success' => 'Record deleted successfully']);
        else session(['error', 'Error on deleting the record']);
        return redirect()->route('region.index');
    }
    public function search(Request $request) {
        $regions = Region::where('status', 1)
            ->where(function($query) use ($request) {
                $query->where('region_name', 'like', '%'.$request->search.'%')
                    ->orWhere('region_manager', 'like', '%'.$request->search.'%')
            ;})
            ->orderBy('id', 'desc')
            ->paginate(15);
        $search = $request->search;
        $regions->appends(['search' => $search]);
        return view('maintenance.region.index', compact('search', 'regions'));
    }
}
