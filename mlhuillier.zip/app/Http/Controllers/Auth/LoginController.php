<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use App\User;
use App\Menu;
use App\UserRole;
use DB;
use Auth;
class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/dashboard';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function login(Request $request){
        if (Auth::attempt([
            'username' => $request->username,
            'password' => $request->password
        ])){

            $useroleid = auth()->user()->role_id;
            $userroleall = UserRole::find($useroleid);

            //Add '' in every user access 
            $userrole = explode(',',$userroleall->access);
            $user_role = array();
            foreach ($userrole as $key => $value) {
                $user_role[] = "'".$value."'";
            }
            $sqlmenu = implode(',', $user_role);

            $subsqlmenu = DB::select(DB::raw('SELECT DISTINCT `parent` FROM `menu` WHERE `name` IN ('.$sqlmenu.')'));

            $roles = array();
            foreach ($subsqlmenu as $key => $object) {
                 $roles[] = $object->parent;
             }


            $parentmenu = Menu::all()
                        ->where('status',1)
                        ->whereIn('id', $roles)
                        ->where('parent', 0);

            $childmenu = Menu::all()
                        ->where('status',1)
                        ->whereIn('name', $userrole)
                        ->where('parent','!=', 0 );
            
            session(['parentmenu' => $parentmenu]);
            session(['childmenu' => $childmenu]);
            return redirect()->route('dashboard');
        }else{
            // session(['error' => $request->username.' | '.$request->password]);
            session(['error' => 'Invalid Username or Password']);
            return redirect('/');
        }


    }

    public function showLoginForm() {
        return view('auth.login');
    }


}
