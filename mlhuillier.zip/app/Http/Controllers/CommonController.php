<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
class CommonController extends Controller {
    public static function getCoiNumber() {
        $coi_number = DB::table('transaction')->max('coi_number');
        return substr('0000000'.(intval($coi_number) + 1), -7);
    }
    public static function getTransactionType($type) {
        switch($type) {
            case 'A':  return 'Family Protect - Plus'; break;
            case 'AO': return 'KP Protect';            break;
            case 'B':  return 'Pinoy Protect - Plus';  break;
            case 'D':  return 'Family Protect';        break;
            case 'R':  return "Pawner's Protect";      break;
        }
    }
    public static function getTransactionTypeCode($type) {
        switch($type) {
            case 'Family Protect - Plus': 'A';  break;
            case 'KP Protect':            'AO'; break;
            case 'Pinoy Protect - Plus':  'B';  break;
            case 'Family Protect':        'D';  break;
            case "Pawner's Protect":      'R';  break;
        }
    }
}
