<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;
use App\Area;
use App\Region;
use App\Branch;
use App\Transaction;
use DB;
use Carbon\Carbon;
class SummaryController extends Controller {
    public function index() {
        $regions = Region::where('status', 1)
            ->orderBy('region_name')
            ->get();
        $areas = Area::where('status', 1)
            ->orderBy('area_name')
            ->get();
        $branches = Branch::where('status', 1)
            ->orderBy('branch_name')
            ->get();
        return view('reports.summary.index', compact('regions', 'areas', 'branches'));
    }
    public function create() { }
    public function store(Request $request) {
        $request->validate([
            'date_from' => 'required',
            'date_to' => 'required',
        ]);
        $row = 3;
        $file_name = 'Summary_Report_'.auth()->user()->id.'.xlsx';
        $style_data_1 = [
            'font' => [
                'bold' => true,
            ],
            'borders' => [
                'left' => [
                    'borderStyle' => Border::BORDER_THIN,
                ],
                'top' => [
                    'borderStyle' => Border::BORDER_THIN,
                ],
                'right' => [
                    'borderStyle' => Border::BORDER_THIN,
                ],
                'bottom' => [
                    'borderStyle' => Border::BORDER_THIN,
                ],
            ],
        ];
        $style_data_2 = [
            'borders' => [
                'left' => [
                    'borderStyle' => Border::BORDER_THICK,
                ],
                'top' => [
                    'borderStyle' => Border::BORDER_THICK,
                ],
                'right' => [
                    'borderStyle' => Border::BORDER_THICK,
                ],
                'bottom' => [
                    'borderStyle' => Border::BORDER_THICK,
                ],
            ],
        ];
        $spreadsheet = new Spreadsheet();
        $with_transaction = false;
        $sheet = $spreadsheet->getActiveSheet();
        // $sheet->setCellValue('A1', 'Summary Report for '.Carbon::parse($request->date_from)->format('m/d/Y').' - '.Carbon::parse($request->date_to)->format('m/d/Y'));
        $sheet->setCellValue('B1', 'FAMILY PROTECT');
        $sheet->setCellValue('F1', 'FAMILY PROTECT PLUS');
        $sheet->setCellValue('J1', 'KWARTA PADALA');
        $sheet->setCellValue('N1', 'PINOY PROTECT');
        $sheet->setCellValue('R1', 'PINOY PROTECT PLUS');
        $sheet->setCellValue('A2', 'Row Labels');
        $sheet->setCellValue('B2', '1-POSTED');
        $sheet->setCellValue('C2', '2-UNPOSTED');
        $sheet->setCellValue('D2', '3-DELETED');
        $sheet->setCellValue('E2', '4-CANCELLED');
        $sheet->setCellValue('F2', '1-POSTED');
        $sheet->setCellValue('G2', '2-UNPOSTED');
        $sheet->setCellValue('H2', '3-DELETED');
        $sheet->setCellValue('I2', '4-CANCELLED');
        $sheet->setCellValue('J2', '1-POSTED');
        $sheet->setCellValue('K2', '2-UNPOSTED');
        $sheet->setCellValue('L2', '3-DELETED');
        $sheet->setCellValue('M2', '4-CANCELLED');
        $sheet->setCellValue('N2', '1-POSTED');
        $sheet->setCellValue('O2', '2-UNPOSTED');
        $sheet->setCellValue('P2', '3-DELETED');
        $sheet->setCellValue('Q2', '4-CANCELLED');
        $sheet->setCellValue('R2', '1-POSTED');
        $sheet->setCellValue('S2', '2-UNPOSTED');
        $sheet->setCellValue('T2', '3-DELETED');
        $sheet->setCellValue('U2', '4-CANCELLED');
        $sheet->getStyle('B1:U2')->getAlignment()->setHorizontal('center');
        $spreadsheet->getActiveSheet()->mergeCells('B1:E1');
        $spreadsheet->getActiveSheet()->mergeCells('F1:I1');
        $spreadsheet->getActiveSheet()->mergeCells('J1:M1');
        $spreadsheet->getActiveSheet()->mergeCells('N1:Q1');
        $spreadsheet->getActiveSheet()->mergeCells('R1:U1');
        $query = DB::table('transaction AS t')
            ->join('users as u', 't.userid_created', '=', 'u.id')
            // ->where('t.status', '!=', 'deleted')
            ->whereBetween('t.date_issued', [$request->date_from, $request->date_to])
            ->groupBy('u.id', 'u.full_name')
            ->orderBy('u.full_name')
            ->select('u.full_name',
                DB::raw("SUM(IF(t.type = 'A' AND t.posted = 1 AND t.status = 'active', t.units, NULL)) AS a_count_1"),
                DB::raw("SUM(IF(t.type = 'AO' AND t.posted = 1 AND t.status = 'active', t.units, NULL)) AS ao_count_1"),
                DB::raw("SUM(IF(t.type = 'B' AND t.posted = 1 AND t.status = 'active', t.units, NULL)) AS b_count_1"),
                DB::raw("SUM(IF(t.type = 'D' AND t.posted = 1 AND t.status = 'active', t.units, NULL)) AS d_count_1"),
                DB::raw("SUM(IF(t.type = 'R' AND t.posted = 1 AND t.status = 'active', t.units, NULL)) AS r_count_1"),
                DB::raw("SUM(IF(t.type = 'A' AND t.posted = 0 AND t.status = 'active', t.units, NULL)) AS a_count_2"),
                DB::raw("SUM(IF(t.type = 'AO' AND t.posted = 0 AND t.status = 'active', t.units, NULL)) AS ao_count_2"),
                DB::raw("SUM(IF(t.type = 'B' AND t.posted = 0 AND t.status = 'active', t.units, NULL)) AS b_count_2"),
                DB::raw("SUM(IF(t.type = 'D' AND t.posted = 0 AND t.status = 'active', t.units, NULL)) AS d_count_2"),
                DB::raw("SUM(IF(t.type = 'R' AND t.posted = 0 AND t.status = 'active', t.units, NULL)) AS r_count_2"),
                DB::raw("SUM(IF(t.type = 'A' AND t.status = 'deleted', t.units, NULL)) AS a_count_3"),
                DB::raw("SUM(IF(t.type = 'AO' AND t.status = 'deleted', t.units, NULL)) AS ao_count_3"),
                DB::raw("SUM(IF(t.type = 'B' AND t.status = 'deleted', t.units, NULL)) AS b_count_3"),
                DB::raw("SUM(IF(t.type = 'D' AND t.status = 'deleted', t.units, NULL)) AS d_count_3"),
                DB::raw("SUM(IF(t.type = 'R' AND t.status = 'deleted', t.units, NULL)) AS r_count_3"),
                DB::raw("SUM(IF(t.type = 'A' AND t.status = 'cancelled', t.units, NULL)) AS a_count_4"),
                DB::raw("SUM(IF(t.type = 'AO' AND t.status = 'cancelled', t.units, NULL)) AS ao_count_4"),
                DB::raw("SUM(IF(t.type = 'B' AND t.status = 'cancelled', t.units, NULL)) AS b_count_4"),
                DB::raw("SUM(IF(t.type = 'D' AND t.status = 'cancelled', t.units, NULL)) AS d_count_4"),
                DB::raw("SUM(IF(t.type = 'R' AND t.status = 'cancelled', t.units, NULL)) AS r_count_4")
            );
        if($request->product) {
            $query = $query->whereIn('t.type', $request->product);
        }
        if($request->branch) {
            $query = $query->whereIn('t.userbranch', $request->branch);
        }
        if($request->area) {
            $branches = Branch::whereIn('area_id', $request->area)->pluck('branch_name');
            $query = $query->whereIn('t.userbranch', $branches);
        }
        if($request->region) {
            $areas = Area::whereIn('region_id', $request->region)->pluck('id');
            $branches = Branch::whereIn('area_id', $areas)->pluck('branch_name');
            $query = $query->whereIn('t.userbranch', $branches);
        }
        $query->chunk(100, function($transactions) use ($spreadsheet, &$row, &$with_transaction, $style_data_1) { // READ AND WRITE $row
            $sheet = $spreadsheet->getActiveSheet();
            foreach($transactions as $transaction) {
                $with_transaction = true;
                $sheet->setCellValue('A'.$row, $transaction->full_name);
                $sheet->setCellValue('B'.$row, $transaction->d_count_1);
                $sheet->setCellValue('C'.$row, $transaction->d_count_2);
                $sheet->setCellValue('D'.$row, $transaction->d_count_3);
                $sheet->setCellValue('E'.$row, $transaction->d_count_4);
                $sheet->setCellValue('F'.$row, $transaction->a_count_1);
                $sheet->setCellValue('G'.$row, $transaction->a_count_2);
                $sheet->setCellValue('H'.$row, $transaction->a_count_3);
                $sheet->setCellValue('I'.$row, $transaction->a_count_4);
                $sheet->setCellValue('J'.$row, $transaction->ao_count_1);
                $sheet->setCellValue('K'.$row, $transaction->ao_count_2);
                $sheet->setCellValue('L'.$row, $transaction->ao_count_3);
                $sheet->setCellValue('M'.$row, $transaction->ao_count_4);
                $sheet->setCellValue('N'.$row, $transaction->r_count_1);
                $sheet->setCellValue('O'.$row, $transaction->r_count_2);
                $sheet->setCellValue('P'.$row, $transaction->r_count_3);
                $sheet->setCellValue('Q'.$row, $transaction->r_count_4);
                $sheet->setCellValue('R'.$row, $transaction->b_count_1);
                $sheet->setCellValue('S'.$row, $transaction->b_count_2);
                $sheet->setCellValue('T'.$row, $transaction->b_count_3);
                $sheet->setCellValue('U'.$row, $transaction->b_count_4);
                foreach(range('A', 'U') as $column) $sheet->getStyle($column.$row)->applyFromArray($style_data_1);
                $row++;
            }
        });
        // TOTALS
        $sheet->setCellValue('A'.$row, 'Grand Total');
        $sheet->setCellValue('B'.$row, '=SUM(B3:B'.($row - 1).')');
        $sheet->setCellValue('C'.$row, '=SUM(C3:C'.($row - 1).')');
        $sheet->setCellValue('D'.$row, '=SUM(D3:D'.($row - 1).')');
        $sheet->setCellValue('E'.$row, '=SUM(E3:E'.($row - 1).')');
        $sheet->setCellValue('F'.$row, '=SUM(F3:F'.($row - 1).')');
        $sheet->setCellValue('G'.$row, '=SUM(G3:G'.($row - 1).')');
        $sheet->setCellValue('H'.$row, '=SUM(H3:H'.($row - 1).')');
        $sheet->setCellValue('I'.$row, '=SUM(I3:I'.($row - 1).')');
        $sheet->setCellValue('J'.$row, '=SUM(J3:J'.($row - 1).')');
        $sheet->setCellValue('K'.$row, '=SUM(K3:K'.($row - 1).')');
        $sheet->setCellValue('L'.$row, '=SUM(L3:L'.($row - 1).')');
        $sheet->setCellValue('M'.$row, '=SUM(M3:M'.($row - 1).')');
        $sheet->setCellValue('N'.$row, '=SUM(N3:N'.($row - 1).')');
        $sheet->setCellValue('O'.$row, '=SUM(O3:O'.($row - 1).')');
        $sheet->setCellValue('P'.$row, '=SUM(P3:P'.($row - 1).')');
        $sheet->setCellValue('Q'.$row, '=SUM(Q3:Q'.($row - 1).')');
        $sheet->setCellValue('R'.$row, '=SUM(R3:R'.($row - 1).')');
        $sheet->setCellValue('S'.$row, '=SUM(S3:S'.($row - 1).')');
        $sheet->setCellValue('T'.$row, '=SUM(T3:T'.($row - 1).')');
        $sheet->setCellValue('U'.$row, '=SUM(U3:U'.($row - 1).')');
        // FINAL TOUCH
        $sheet->getStyle('B2:U'.($row + 1))->getNumberFormat()->setFormatCode('#,##0_-');
        $sheet->getStyle('A1:U2')->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('D9E1F2');
        $sheet->getStyle('A'.$row.':U'.$row)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('D9E1F2');
        foreach(range('A', 'U') as $column) {
            $sheet->getStyle($column.'1')->applyFromArray($style_data_1);
            $sheet->getStyle($column.'2')->applyFromArray($style_data_1);
            $sheet->getStyle($column.$row)->applyFromArray($style_data_1);
        }
        $sheet->getStyle('B1:E'.$row)->applyFromArray($style_data_2);
        $sheet->getStyle('F1:I'.$row)->applyFromArray($style_data_2);
        $sheet->getStyle('J1:M'.$row)->applyFromArray($style_data_2);
        $sheet->getStyle('N1:Q'.$row)->applyFromArray($style_data_2);
        $sheet->getStyle('R1:U'.$row)->applyFromArray($style_data_2);
        /* AUTOSIZE START */
        $cellIterator = $sheet->getRowIterator()->current()->getCellIterator();
        $cellIterator->setIterateOnlyExistingCells(true);
        foreach ($cellIterator as $cell) {
            $sheet->getColumnDimension($cell->getColumn())->setAutoSize(true);
        }
        /* AUTOSIZE END */
        if($with_transaction) {
            $writer = new Xlsx($spreadsheet);
            if(strpos(url()->current(), 'public') !== false) $public = '../';
            else $public = '';
            $result = $writer->save($public.'public/storage/downloads/'.$file_name);
            // $result = $writer->save('public/storage/downloads/'.$file_name);
            session([
                'download' => $file_name,
                'success' => 'File Created Successfully'
            ]);
        } else {
            session(['error' => 'No records found']);
        }
        return redirect()->route('summary.index');
    }
    public function show($id) { }
    public function edit($id) { }
    public function update(Request $request, $id) { }
    public function destroy($id) { }
}
