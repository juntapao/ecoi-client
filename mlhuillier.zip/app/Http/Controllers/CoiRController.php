<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Transaction;
use App\CoiAO ;
use App\Branch;
use App\PolicySeries;
use App\Insuran_price;
use App\Setting;
use DB;
use PDF;
class CoiRController extends Controller {
    public function index() {
        Transaction::whereNull('posted')
            ->where('type', 'R')
            ->where('date_issued', '<', DB::raw('CURDATE()'))
            ->where('userbranch', Branch::find(auth()->user()->branch_id)->branch_name)
            ->update(['status' => 'deleted']);
        $transactions = DB::table('transaction')
            ->where('type', 'R')
            ->where('status', '!=', 'deleted')
            ->where('userbranch', Branch::find(auth()->user()->branch_id)->branch_name)
            ->orderBy('id', 'desc')
            ->paginate(15);
        return view('transactions.coi_r.index', compact('transactions'));
    }
    public function create() {
        $branch = Branch::find(auth()->user()->branch_id);
        $datenow = date('Y-m-d');
        return view('transactions.coi_r.create', compact('branch', 'datenow'));
    }
    public function store(Request $request) {
        $this->validate($request, [
            // 'coi_number' => 'required|unique:transaction',
            'ticket_number' => 'required',
            'beneficiary' => 'required',
            'insured_name' => 'required',
            'units' => 'required|numeric|between:1,5',
        ]);
        try {
            $transaction = new Transaction;
            $transaction->date_issued = Carbon::now()->format('Y-m-d');
            $transaction->price = Insuran_price::find(3)->price;
            $transaction->coi_number = CommonController::getCoiNumber();
            $transaction->policy_number = Setting::find(5)->value;
            $transaction->units = $request->units;
            $transaction->ticket_number = strtoupper($request->ticket_number);
            $transaction->insured_name = strtoupper($request->insured_name);
            $transaction->beneficiary = strtoupper($request->beneficiary);
            $transaction->type = 'R';
            $transaction->status = 'active';
            $transaction->userid_created = auth()->user()->id;
            $transaction->userbranch = $request->userbranch;
            $transaction->userid_modified = auth()->user()->id;
            if($transaction->save()) session(['success' => 'Record saved successfully']);
            else session(['error', 'Error on saving the record']);
        } catch(QueryException $ex) {
            return redirect()->route('coi_r.create')->withInput();
        }
        return redirect()->route('coi_r.show', $transaction->id);
    }
    public function show($id) {
        $branch = Branch::find(auth()->user()->branch_id);
        $transaction = Transaction::find($id);
        return view('transactions.coi_r.show', compact('id', 'transaction'));
    }
    public function edit($id) {
        $transaction = Transaction::find($id);
        return view('transactions.coi_r.edit')
            ->with('transaction', $transaction);
    }
    public function update(Request $request, $id) {
        $this->validate($request, [
            'ticket_number' => 'required',
            'beneficiary' => 'required',
            'insured_name' => 'required',
            'units' => 'required|numeric|between:1,5',
            'reason' => 'required',
        ]);
        $transaction = Transaction::find($id);
        $transaction->price = Insuran_price::find(3)->price;
        $transaction->units = $request->units;
        $transaction->ticket_number = strtoupper($request->ticket_number);
        $transaction->insured_name = strtoupper($request->insured_name);
        $transaction->beneficiary = strtoupper($request->beneficiary);
        $transaction->reason = strtoupper($request->reason);
        $transaction->status = 'edited';
        $transaction->userid_modified = auth()->user()->id;
        if($transaction->save()) session(['success' => 'Record saved successfully']);
        else session(['error', 'Error on saving the record']);
        return redirect()->route('coi_r.show', $transaction->id);
    }
    public function destroy($id) {
        $transaction = Transaction::find($id);
        $transaction->status = 'deleted';
        if($transaction->save()) session(['success' => 'Record deleted successfully']);
        else session(['error', 'Error on deleting the record']);
        return redirect()->route('coi_r.index');
    }
    public function search(Request $request) {
        $transactions = DB::table('transaction')
            ->where('type', 'R')
            ->where('status', '!=', 'deleted')
            ->where('userbranch', Branch::find(auth()->user()->branch_id)->branch_name)
            ->where(function($query) use ($request) {
                $query->where('coi_number', 'like', '%'.$request->search.'%')
                    ->orWhere('policy_number', 'like', '%'.$request->search.'%')
                    ->orWhere('insured_name', 'like', '%'.$request->search.'%');
            })
            ->orderBy('id', 'desc')
            ->paginate(15);
        $search = $request->search;
        $transactions->appends(['search' => $search]);
        return view('transactions.coi_r.index', compact('search', 'transactions'));
    }
    public function post($id) {
        $transaction = Transaction::find($id);
        $transaction->posted = 1;
        if($transaction->save()) session(['success' => 'Record posted successfully']);
        else session(['error', 'Error on posting the record']);
        return redirect()->route('coi_r.index');
    }
    public function print($id) {
        $transaction = Transaction::find($id);
        if($transaction->type == 'R') {
            $holder = array();
            $holder1 = 0;
            $holder2 = 0;
            $holder3 = 0;
            // ==============================
            //  Principal Sum & Unprovoked Murder
            // ==============================
                ### Principal sum###
            for ($i=0; $i < $transaction->units; $i++) { 
                $holder1 = $holder1 + 30000;
                $holder['principal_sum'] =  number_format($holder1,2);
            }$holder1 = 0;
                ### Unprovoked Murder ###
            for ($i=0; $i < $transaction->units; $i++) { 
                // if ($i < 2) {
                    $holder2 = $holder2 + 20000;
                    $holder['unprovoked_murder'] =  number_format(($holder2 > 60000 ? 60000 : $holder2),2);
                // }
            }
            $holder2 = 0;
            $view = \View::make('transactions.coi_r.coi_r-pdf', compact('transaction', 'holder'));
            $html_content = $view->render();
            PDF::SetTitle('COI R');
            PDF::AddPage("P", "A4");
            PDF::SetFooterMargin(PDF_MARGIN_FOOTER);
            PDF::SetAutoPageBreak(TRUE, 0);
            PDF::Image("../public/images/a.png", 160, 82, 20);
            PDF::Image("../public/images/logo.png", 107, 12, 20);
            PDF::Image("../public/images/ml_logo.png", 15, 12, 48);
            PDF::writeHTML($html_content, true, false, true, false, '');
        } else {
            PDF::AddPage("P", "A4");
            PDF::writeHTML('<h3>Invalid record</h3>', true, false, true, false, '');
        }
        PDF::SetFont('Helvetica', '', 10);
        PDF::Output('COI R.pdf');
    }
}
