<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use App\Transaction;
use App\Area;
use App\Region;
use App\Branch;
use App\Exports\Detailed;
use DB;
class DetailedController extends Controller {
    public function index() {
        $regions = Region::where('status', 1)
            ->orderBy('region_name')
            ->get();
        $areas = Area::where('status', 1)
            ->orderBy('area_name')
            ->get();
        $branches = Branch::where('status', 1)
            ->orderBy('branch_name')
            ->get();
        return view('reports.detailed.index', compact('regions', 'areas', 'branches'));
    }
    public function create() { }
    public function store(Request $request) {
        $request->validate([
            'date_from' => 'required',
            'date_to' => 'required',
        ]);
        $row = 2;
        $file_name = 'Detailed_Report_'.auth()->user()->id.'.xlsx';
        $spreadsheet = new Spreadsheet();
        $with_transaction = false;
        Transaction::where('status', '!=', 'deleted')
            ->whereBetween('date_issued', [$request->date_from, $request->date_to])
            ->chunk(300, function($transactions) use ($spreadsheet, &$row, &$with_transaction, $request) { // READ AND USE $row
                if($request->product) {
                    $transactions = $transactions->whereIn('type', $request->product);
                }
                if($request->branch) {
                    $transactions = $transactions->whereIn('userbranch', $request->branch);
                }
                if($request->area) {
                    $branches = Branch::whereIn('area_id', $request->area)->pluck('branch_name');
                    $transactions = $transactions->whereIn('userbranch', $branches);
                }
                if($request->region) {
                    $areas = Area::whereIn('region_id', $request->region)->pluck('id');
                    $branches = Branch::whereIn('area_id', $areas)->pluck('branch_name');
                    $transactions = $transactions->whereIn('userbranch', $branches);
                }
                $sheet = $spreadsheet->getActiveSheet();
                $sheet->setCellValue('A1', 'COI Number');
                $sheet->setCellValue('B1', 'Policy Number');
                $sheet->setCellValue('C1', 'Insured Name');
                $sheet->setCellValue('D1', 'Type');
                $sheet->setCellValue('E1', 'Units');
                $sheet->setCellValue('F1', 'Price');
                $sheet->setCellValue('G1', 'Date Issued');
                $sheet->setCellValue('H1', 'Status');
                $sheet->setCellValue('I1', 'Posted');
                $sheet->setCellValue('J1', 'User Branch');
                $sheet->setCellValue('K1', 'User Name');
                foreach($transactions as $transaction) {
                    $with_transaction = true;
                    $sheet->setCellValue('A'.$row, $transaction->coi_number);
                    $sheet->setCellValue('B'.$row, $transaction->policy_number);
                    $sheet->setCellValue('C'.$row, $transaction->insured_name);
                    $sheet->setCellValue('D'.$row, CommonController::getTransactionType($transaction->type));
                    $sheet->setCellValue('E'.$row, $transaction->units);
                    $sheet->setCellValue('F'.$row, $transaction->price);
                    $sheet->setCellValue('G'.$row, $transaction->date_issued);
                    $sheet->setCellValue('H'.$row, $transaction->status);
                    $sheet->setCellValue('I'.$row, $transaction->posted);
                    $sheet->setCellValue('J'.$row, $transaction->userbranch);
                    $sheet->setCellValue('K'.$row, $transaction->user->username);
                    $row++;
                }
            });
        if($with_transaction) {
            $writer = new Xlsx($spreadsheet);
            if(strpos(url()->current(), 'public') !== false) $public = '../';
            else $public = '';
            $result = $writer->save($public.'public/storage/downloads/'.$file_name);
            // $result = $writer->save('public/storage/downloads/'.$file_name);
            session([
                'download' => $file_name,
                'success' => 'File Created Successfully'
            ]);
        } else {
            session(['error' => 'No records found']);
        }
        return redirect()->route('detailed.index');
    }
    public function show($id) { }
    public function edit($id) { }
    public function update(Request $request, $id) { }
    public function destroy($id) { }
}




// $sheet->setCellValue('A1', 'KPT Number');
// $sheet->setCellValue('B1', 'COI Number');
// $sheet->setCellValue('C1', 'Policy Number');
// $sheet->setCellValue('D1', 'BOS Entry Number');
// $sheet->setCellValue('E1', 'Ticket Number');
// $sheet->setCellValue('F1', 'Insured Name');
// $sheet->setCellValue('G1', 'Address');
// $sheet->setCellValue('H1', 'Civil Status');
// $sheet->setCellValue('I1', 'Beneficiary');
// $sheet->setCellValue('J1', 'Relationship');
// $sheet->setCellValue('K1', 'Date of Birth');
// $sheet->setCellValue('L1', 'Guardian 1');
// $sheet->setCellValue('M1', 'Guardian 1 Date of Birth');
// $sheet->setCellValue('N1', 'Guardian 2');
// $sheet->setCellValue('O1', 'Guardian 2 Date of Birth');
// $sheet->setCellValue('P1', 'Child / Siblings 1');
// $sheet->setCellValue('Q1', 'Child / Siblings 1 Date of Birth');
// $sheet->setCellValue('R1', 'Child / Siblings 2');
// $sheet->setCellValue('S1', 'Child / Siblings 2 Date of Birth');
// $sheet->setCellValue('T1', 'Child / Siblings 3');
// $sheet->setCellValue('U1', 'Child / Siblings 3 Date of Birth');
// $sheet->setCellValue('V1', 'Child / Siblings 4');
// $sheet->setCellValue('Q1', 'Child / Siblings 4 Date of Birth');
// $sheet->setCellValue('X1', 'Type');
// $sheet->setCellValue('Y1', 'Units');
// $sheet->setCellValue('Z1', 'Date Issued');
// $sheet->setCellValue('AA1', 'Time Issued');
// $sheet->setCellValue('AB1', 'Status');
// $sheet->setCellValue('AC1', 'Posted');
// $sheet->setCellValue('AD1', 'User Created');
// $sheet->setCellValue('AE1', 'User Branch');
// $sheet->setCellValue('AF1', 'Reason');