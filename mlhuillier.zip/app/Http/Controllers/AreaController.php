<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Region;
use App\Area;
class AreaController extends Controller {
    public function index() {
        $areas = Area::where('status', 1)
            ->orderBy('id', 'desc')
            ->paginate(15);
        return view('maintenance.area.index', compact('areas'));
    }
    public function create() {
        $regions = Region::where('status', 1)
            ->orderBy('region_name')
            ->get();
        return view('maintenance.area.create', compact('regions'));
    }
    public function store(Request $request) {
        $request->validate([
            'area_name' => 'required',
            'area_manager' => 'required',
            'region_id' => 'required',
        ]);
        $area = new Area;
        $area->area_name = strtoupper($request->area_name);
        $area->area_manager = strtoupper($request->area_manager);
        $area->region_id = $request->region_id;
        $area->status = 1;
        $area->userid_created = auth()->user()->id;
        $area->userid_modified = auth()->user()->id;
        if($area->save()) session(['success' => 'Record saved successfully']);
        else session(['error', 'Error on saving the record']);
        return redirect()->route('area.show', $area->id);
    }
    public function show($id) {
        $area = Area::find($id);
        return view('maintenance.area.show', compact('area'));
    }
    public function edit($id) {
        $area = Area::find($id);
        $regions = Region::where('status', 1)
            ->orderBy('region_name')
            ->get();
        return view('maintenance.area.edit', compact('area', 'regions'));
    }
    public function update(Request $request, $id) {
        $request->validate([
            'area_name' => 'required',
            'area_manager' => 'required',
            'region_id' => 'required',
        ]);
        $area = Area::find($id);
        $area->area_name = strtoupper($request->area_name);
        $area->area_manager = strtoupper($request->area_manager);
        $area->region_id = $request->region_id;
        $area->status = 1;
        $area->userid_modified = auth()->user()->id;
        if($area->save()) session(['success' => 'Record saved successfully']);
        else session(['error', 'Error on saving the record']);
        return redirect()->route('area.show', $area->id);
    }
    public function destroy($id) {
        $area = Area::find($id);
        $area->status = 0;
        $area->userid_modified = auth()->user()->id;
        if($area->save()) session(['success' => 'Record deleted successfully']);
        else session(['error', 'Error on deleting the record']);
        return redirect()->route('area.index');
    }
    public function search(Request $request) {
        $areas = Area::where('status', 1)
            ->where(function($query) use ($request) {
                $query->where('area_name', 'like', '%'.$request->search.'%')
                    ->orWhere('area_manager', 'like', '%'.$request->search.'%')
            ;})
            ->orderBy('id', 'desc')
            ->paginate(15);
        $search = $request->search;
        $areas->appends(['search' => $search]);
        return view('maintenance.area.index', compact('search', 'areas'));
    }
}
