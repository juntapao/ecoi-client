<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\UserRole;
use App\Menu;
use DB;
class RolesController extends Controller {
    public function index() {
        // $roles = UserRole::all()->where('status', 1);
        // $parentmenu = Menu::all()->where('parent', 0);
        // $childmenu = Menu::all()->where('parent', '<>',0);
        // return view('maintenance/roles.index', compact('roles','parentmenu','childmenu'));
        $roles = UserRole::where('status', 1)
            ->orderBy('id', 'desc')
            ->paginate(15);
        return view('maintenance.roles.index', compact('roles'));
    }
    public function create() {
        $parentmenus = Menu::where('parent', 0)->get();
        $childmenus = Menu::where('parent', '<>', 0)->get();
        return view('maintenance.roles.create', compact('parentmenus', 'childmenus'));
    }
    public function store(Request $request) {
        $this->validate($request, [
            'role_name' => 'required',
            'access' => 'required'
        ]);
        $role = new UserRole;
        $role->role_name = strtoupper($request->role_name);
        $role->access = implode(',', $request->access);
        $role->status = 1;
        $role->userid_created = auth()->user()->id;
        $role->userid_modified = auth()->user()->id;
        if($role->save()) session(['success' => 'Record saved successfully']);
        else session(['error', 'Error on saving the record']);
        return redirect()->route('roles.show', $role->id);
    }
    public function show($id) {
        $role = UserRole::find($id);
        $parentmenus = Menu::where('parent', 0)->get();
        $childmenus = Menu::where('parent', '<>', 0)->get();
        return view('maintenance.roles.show', compact('role', 'parentmenus', 'childmenus'));
    }
    public function edit($id) {
        $role = UserRole::find($id);
        $parentmenus = Menu::where('parent', 0)->get();
        $childmenus = Menu::where('parent', '<>', 0)->get();
        return view('maintenance.roles.edit', compact('role', 'parentmenus', 'childmenus'));
    }
    public function update(Request $request, $id) {
        $this->validate($request, [
            'role_name' => 'required',
            'access' => 'required'
        ]);
        $role = UserRole::find($id);
        $role->role_name = strtoupper($request->role_name);
        $role->access = implode(',', $request->access);
        $role->userid_modified = auth()->user()->id;
        if($role->save()) session(['success' => 'Record saved successfully']);
        else session(['error', 'Error on saving the record']);
        return redirect()->route('roles.show', $role->id);
    }
    public function destroy($id) {
        if(UserRole::destroy($id)) session(['success' => 'Record deleted successfully']);
        else session(['error', 'Error on deleting the record']);
        return redirect()->route('roles.index');
    }
    public function search(Request $request) {
        $roles = DB::table('user_roles')
            ->where('status', 1)
            ->where(function($query) use ($request) {
                $query->where('role_name', 'like', '%'.$request->search.'%')
                    ->orWhere('access', 'like', '%'.$request->search.'%');
            })
            ->orderBy('id', 'desc')
            ->paginate(15);
        $search = $request->search;
        return view('maintenance.roles.index', compact('search', 'roles'));
    }
}
