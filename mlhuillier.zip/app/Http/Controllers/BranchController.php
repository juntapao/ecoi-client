<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Branch;
use App\Area;
use App\Region;
use DB;
use Response;
class BranchController extends Controller {
    public function index() {   
        //DB::select(DB::raw("SELECT * FROM branch where status = 1"));               
        // $branch = Branch::all()->where('status', 1);
        // $region = Region::all()->where('status', 1);
        // $areas = Area::all()->where('status', 1);
        // return view('maintenance/branch.index', compact('branch','region','areas','ajaxget'));
        $branches = Branch::where('status', 1)
            ->orderBy('id', 'desc')
            ->paginate(15);
        return view('maintenance.branch.index', compact('branches'));
    }
    public function create() {
        $regions = Region::where('status', 1)
            ->orderBy('region_name')
            ->get();
        $areas = Area::where('status', 1)
            ->orderBy('area_name')
            ->get();
        return view('maintenance.branch.create', compact('regions', 'areas'));
    }
    public function store(Request $request) {
        $request->validate([
            // 'region' => 'required',
            'area_id' => 'required',
            'branch_name' => 'required',
            'code' => 'required',
            'city' => 'required',
            'province' => 'required',
        ]);
        $branch = new Branch;
        $branch->branch_name = $request->branch_name;
        // $branch->region = $request->region;
        $branch->area_id = $request->area_id;
        $branch->city = $request->city;
        $branch->province = $request->province;
        $branch->code = $request->code;
        $branch->status = 1;
        $branch->userid_created = auth()->user()->id;
        $branch->userid_modified = auth()->user()->id;
        if($branch->save()) session(['success' => 'Record saved successfully']);
        else session(['error', 'Error on saving the record']);
        return redirect()->route('branch.show', $branch->id);
        // //Create Branch
        // $commandregion = $request->input('commandregion');
        // $commandarea = $request->input('commandarea');
        // $commandbranch = $request->input('commandbranch');
        // // echo $commandbranch;
        // // echo $commandarea;
        // // echo $commandregion;
        // if ($commandregion) {
        //     $status = 1;
        //     $region = new Region;
        //     $region->region_name = strtoupper($request->input('region_name'));
        //     $region->region_manager = strtoupper($request->input('region_manager'));
        //     $region->status = $status;
        //     $region->userid_created = auth()->user()->id;
        //     $region->userid_modified = auth()->user()->id;
        //     $region->save();
        //     return redirect('maintenance/branch')->with('success', 'Region Created');
        // }
        // if ($commandarea) {
        //     $status = 1;
        //     $area = new Area;
        //     $area->area_name = strtoupper($request->input('area_name'));
        //     $area->region = strtoupper($request->input('region_area_name'));
        //     $area->area_manager = strtoupper($request->input('area_manager'));
        //     $area->status = $status;
        //     $area->userid_created = auth()->user()->id;
        //     $area->userid_modified = auth()->user()->id;
        //     $area->save();
        //     return redirect('maintenance/branch')->with('success', 'Area Created');
        // }
        // if ($commandbranch) {
        //     $status = 1;
        //     $branch = new Branch;
        //     // $areas = Area::find($request->input('area_branch_name'));
        //     $branch->area = strtoupper($request->input('area_branch_name'));
        //     $branch->region = strtoupper($request->input('region_branch_name'));
        //     $branch->branch_name = strtoupper($request->input('branch_name'));
        //     $branch->code = strtoupper($request->input('code'));
        //     $branch->city = strtoupper($request->input('city'));
        //     $branch->province = strtoupper($request->input('province'));
        //     $branch->status = $status;
        //     $branch->userid_created = auth()->user()->id;
        //     $branch->userid_modified = auth()->user()->id;
        //     $branch->save();
        //     return redirect('maintenance/branch')->with('success', 'Branch Created');
        // }
    }
    public function show($id) {
        $branch = Branch::find($id);
        return view('maintenance.branch.show', compact('branch'));
    }
    public function edit($id) {
        $branch = Branch::find($id);
        $regions = Region::where('status', 1)
            ->orderBy('region_name')
            ->get();
        $areas = Area::where('status', 1)
            ->orderBy('area_name')
            ->get();
        return view('maintenance.branch.edit', compact('branch', 'regions', 'areas'));    
    }
    public function update(Request $request, $id) {
        $request->validate([
            // 'region' => 'required',
            'area_id' => 'required',
            'branch_name' => 'required',
            'code' => 'required',
            'city' => 'required',
            'province' => 'required',
        ]);
        $branch = Branch::find($id);
        $branch->branch_name = $request->branch_name;
        // $branch->region = $request->region;
        $branch->area_id = $request->area_id;
        $branch->city = $request->city;
        $branch->province = $request->province;
        $branch->code = $request->code;
        $branch->userid_modified = auth()->user()->id;
        if($branch->save()) session(['success' => 'Record saved successfully']);
        else session(['error', 'Error on saving the record']);
        return redirect()->route('branch.show', $branch->id);
        //Update Branch
        // $branch = Branch::find($id);
        // $branch->branch_name = strtoupper($request->input('branch_name'));
        // $branch->code = strtoupper($request->input('code'));
        // $branch->userid_modified = auth()->user()->id;
        // $branch->save();
        // return redirect('maintenance/branch')->with('success', 'Branch Updated');
        // $commandregion = $request->input('command_edit_region');
        // $commandarea = $request->input('command_edit_area');
        // $commandbranch = $request->input('command_edit_branch');
        // if($commandregion) {
        //     $region = Region::find($id);
        //     $region->region_name = strtoupper($request->input('region_name'));
        //     $region->region_manager = strtoupper($request->input('region_manager'));
        //     $region->userid_modified = auth()->user()->id;
        //     $region->save();
        //     return redirect('maintenance/branch')->with('success', 'Region Updated');
        // }
        // if ($commandarea) {
        //     $area = Area::find($id);
        //     $area->area_name = strtoupper($request->input('area_name'));
        //     $area->region = strtoupper($request->input('region_area_name'));
        //     $area->area_manager = strtoupper($request->input('area_manager'));
        //     $area->userid_modified = auth()->user()->id;
        //     $area->save();
        //     return redirect('maintenance/branch')->with('success', 'Area Updated');
        // }
        // if ($commandbranch) {
        //     $branch = Branch::find($id);
        //     $branch->area = strtoupper($request->input('area_branch_name_edit'));
        //     $branch->region = strtoupper($request->input('region_branch_name_edit'));
        //     $branch->branch_name = strtoupper($request->input('branch_name'));
        //     $branch->code = strtoupper($request->input('code'));
        //     $branch->city = strtoupper($request->input('city'));
        //     $branch->province = strtoupper($request->input('province'));
        //     $branch->userid_modified = auth()->user()->id;
        //     $branch->save();
        //     return redirect('maintenance/branch')->with('success', 'Branch Updated');
        // }

    }
    public function destroy(Request $request, $id) {
        $branch = Branch::find($id);
        $branch->status = 0;
        $branch->userid_modified = auth()->user()->id;
        if($branch->save()) session(['success' => 'Record deleted successfully']);
        else session(['error', 'Error on deleting the record']);
        return redirect()->route('branch.index');
        // $status = 0;
        // $branch = Branch::find($id);
        // $branch->status = $status;
        // $branch->save();
        // return redirect('maintenance/branch')->with('success', 'Branch Deleted');
        // $commandregion = $request->input('command_delete_region');
        // $commandarea = $request->input('command_delete_area');
        // $commandbranch = $request->input('command_delete_branch');
        // if ($commandregion) {
        //     $status = 0;
        //     $region = Region::find($id);
        //     $region->status = $status;
        //     $region->save();
        //     return redirect('maintenance/branch')->with('success', 'Region Deleted');
        // }
        // if ($commandarea) {
        //     $status = 0;
        //     $area = Area::find($id);
        //     $area->status = $status;
        //     $area->save();
        //     return redirect('maintenance/branch')->with('success', 'Area Deleted');
        // }
        // if ($commandbranch) {
        //     $status = 0;
        //     $branch = Branch::find($id);
        //     $branch->status = $status;
        //     $branch->save();
        //     return redirect('maintenance/branch')->with('success', 'Branch Deleted');
        // }
    }
    // public function edit_region($id) {
    //     $region = Region::find($id);
    //     return view('maintenance/branch.edit_region')->with('region', $region);
    // }
    // public function edit_area($id) {
    //     $areas = Area::find($id);
    //     $region = Region::all()
    //         ->where('status', 1);
    //     return view('maintenance/branch.edit_area', compact('areas','region'));
    // }
    // public function getArea($id) {
    //     // $areadata = Area::all()
    //     //     ->where('region',$id)
    //     //     ->whereNotIn('status',0);
    //     $areadata = DB::select(DB::raw('SELECT * FROM `areas` WHERE `region` = "'.$id.'"'));

    //     // echo json_encode($areadata);
    //     // exit;
    //     return Response::json($areadata);
    //     // return response()->json($areadata);
    // }
    // public function getArea_edit($id) {
    //     $region = $_GET['region'];
    //     // $areadata = Area::all()
    //     //     ->where('region',$id)
    //     //     ->whereNotIn('status',0);
    //     $areadatas = DB::select(DB::raw('SELECT * FROM `areas` WHERE `region` = "'.$region.'"'));
    //     // echo json_encode($areadata);
    //     // exit;
    //     return Response::json($areadatas);
    //     // return response()->json($areadata);
    // }
    public function search(Request $request) {
        $branches = Branch::where('status', 1)
            ->where(function($query) use ($request) {
                $query->where('branch_name', 'like', '%'.$request->search.'%')
                    // ->orWhere('region', 'like', '%'.$request->search.'%')
                    // ->orWhere('area', 'like', '%'.$request->search.'%')
                    ->orWhere('city', 'like', '%'.$request->search.'%')
                    ->orWhere('province', 'like', '%'.$request->search.'%')
                    ->orWhere('code', 'like', '%'.$request->search.'%');
            })
            ->orderBy('id', 'desc')
            ->paginate(15);
        $search = $request->search;
        $branches->appends(['search' => $search]);
        return view('maintenance.branch.index', compact('search', 'branches'));
    }
}
