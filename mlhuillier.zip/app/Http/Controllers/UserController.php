<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\User;
use App\UserRole;
use App\Branch;
use DB;
class UserController extends Controller {
    public function index() {
        $users = User::where('status', 1)
            ->orderBy('id', 'desc')
            ->paginate(15);
        return view('maintenance.users.index', compact('users'));
    }
    public function create() {
        $roles = UserRole::where('status', 1)->get();
        $branches = Branch::where('status', 1)->get();
        return view('maintenance.users.create', compact('roles', 'branches'));
    }
    public function store(Request $request) {
        $this->validate($request, [
            'username' => 'required|unique:users',
            'full_name' => 'required',
            'branch_id' => 'required',
            'role_id' => 'required',
            'password' => 'required|string|min:6',
        ]);
        $user = new User;
        $user->username = $request->username;
        $user->password = bcrypt($request->input('password'));
        $user->full_name = $request->full_name;
        $user->branch_id = $request->branch_id;
        $user->role_id = $request->role_id;
        $user->status = 1;
        $user->userid_created = auth()->user()->id;
        $user->userid_modified = auth()->user()->id;
        if($user->save()) session(['success' => 'Record saved successfully']);
        else session(['error', 'Error on saving the record']);
        return redirect()->route('users.show', $user->id);
    }
    public function show($id) {
        $user = User::find($id);
        return view('maintenance.users.show', compact('user'));
    }
    public function edit($id) {
        $user = User::find($id);
        $roles = UserRole::where('status', 1)->get();
        $branches = Branch::where('status', 1)->get();
        return view('maintenance.users.edit', compact('user', 'branches', 'roles'));
    }
    public function update(Request $request, $id) {
        $this->validate($request, [
            'username' => 'required',
            'full_name' => 'required',
            'branch_id' => 'required',
            'role_id' => 'required',
        ]);
        $user = User::find($id);
        $user->username = $request->username;
        if($request->password) {
            $this->validate($request, [
                'password' => 'string|min:6',
            ]);
            $user->password = bcrypt($request->password);
        }
        $user->full_name = $request->full_name;
        $user->branch_id = $request->branch_id;
        $user->role_id = $request->role_id;
        $user->userid_modified = auth()->user()->id;
        if($user->save()) session(['success' => 'Record saved successfully']);
        else session(['error', 'Error on saving the record']);
        return redirect()->route('users.show', $user->id);
    }
    public function destroy($id) {
        if(User::destroy($id)) session(['success' => 'Record deleted successfully']);
        else session(['error', 'Error on deleting the record']);
        return redirect()->route('users.index');
    }
    public function search(Request $request) {
        // $branch_ids = Branch::where('branch_name', 'like', '%'.$request->search.'%')->pluck('id');
        $users = User::where('status', 1)
            // ->where(function($query) use ($request, $branch_ids) {
            ->where(function($query) use ($request) {
                $query->where('username', 'like', '%'.$request->search.'%')
                    ->orWhere('full_name', 'like', '%'.$request->search.'%')
                    // ->orWhereIn('branch_id', [1])
                    ;
            })
            ->orderBy('id', 'desc')
            ->paginate(15);
        $search = $request->search;
        $users->appends(['search' => $search]);
        return view('maintenance.users.index', compact('search', 'users'));
    }
}
