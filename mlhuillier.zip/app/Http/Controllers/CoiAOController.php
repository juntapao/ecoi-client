<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Database\QueryException;
use Carbon\Carbon;
use App\Transaction;
use App\CoiAO ;
use App\Branch;
use App\PolicySeries;
use App\Insuran_price;
use App\Setting;
use DB;
use PDF;
class CoiAOController extends Controller {
    public function index() {
        Transaction::whereNull('posted')
            ->where('type', 'AO')
            ->where('date_issued', '<', DB::raw('CURDATE()'))
            ->where('userbranch', Branch::find(auth()->user()->branch_id)->branch_name)
            ->update(['status' => 'deleted']);
        $transactions = DB::table('transaction')
            ->where('type', 'AO')
            ->where('status', '!=', 'deleted')
            ->where('userbranch', Branch::find(auth()->user()->branch_id)->branch_name)
            ->orderBy('id', 'desc')
            ->paginate(15);
        return view('transactions.coi_ao.index', compact('transactions'));
    }
    public function create() {
        $branch = Branch::find(auth()->user()->branch_id);
        $datenow = date('Y-m-d');
        return view('transactions.coi_ao.create', compact('branch', 'datenow'));
    }
    public function store(Request $request) {
        $this->validate($request, [
            // 'coi_number' => 'required|unique:transaction',
            // 'kpt_number' => 'required',
            'insured_name' => 'required',
            'beneficiary' => 'required',
            'units' => 'required|numeric|between:1,5',
        ]);
        try {
            $transaction = new Transaction;
            $transaction->date_issued = Carbon::now()->format('Y-m-d');
            $transaction->price = Insuran_price::find(1)->price;
            $transaction->coi_number = CommonController::getCoiNumber();
            // $transaction->coi_number = '0000981';
            $transaction->policy_number = Setting::find(2)->value;
            $transaction->units = $request->units;
            $transaction->kpt_number = strtoupper($request->kpt_number);
            $transaction->insured_name = strtoupper($request->insured_name);
            $transaction->beneficiary = strtoupper($request->beneficiary);
            $transaction->type = 'AO';
            $transaction->status = 'active';
            $transaction->userid_created = auth()->user()->id;
            $transaction->userbranch = $request->userbranch;
            $transaction->userid_modified = auth()->user()->id;
            if($transaction->save()) session(['success' => 'Record saved successfully']);
            else session(['error', 'Error on saving the record']);
        } catch(QueryException $ex) {
            // session(['error', $ex->getMessage()]);
            return redirect()->route('coi_ao.create')->withInput();
        }
        // $seriess = PolicySeries::find('5');
        // $polseries = $seriess->series;
        // $polseries1 = $polseries + 1;
        // $coiseries = $seriess->coi_no;
        // $coiseries1 = $coiseries + 1;
        // $seriess->series = sprintf('%06d',$polseries1);
        // $seriess->coi_no = sprintf('%07d',$coiseries1);
        // $seriess->save();
        return redirect()->route('coi_ao.show', $transaction->id);
    }
    public function show($id) {
        $branch = Branch::find(auth()->user()->branch_id);
        $transaction = Transaction::find($id);
        return view('transactions.coi_ao.show', compact('id', 'transaction'));
    }
    public function edit($id) {
        $transaction = Transaction::find($id);
        return view('transactions.coi_ao.edit')
            ->with('transaction', $transaction);
    }
    public function update(Request $request, $id) {
        $request->validate([
            // 'kpt_number' => 'required',
            'insured_name' => 'required',
            'beneficiary' => 'required',
            'units' => 'required|min:1|max:5',
            'reason' => 'required',
        ]);
        $transaction = Transaction::find($id);
        $transaction->price = Insuran_price::find(1)->price;
        $transaction->kpt_number = strtoupper($request->kpt_number);
        $transaction->units = $request->units;
        $transaction->insured_name = strtoupper($request->insured_name);
        $transaction->beneficiary = strtoupper($request->beneficiary);
        $transaction->reason = strtoupper($request->reason);
        $transaction->status = 'edited';
        $transaction->userid_modified = auth()->user()->id;
        if($transaction->save()) session(['success' => 'Record saved successfully']);
        else session(['error', 'Error on saving the record']);
        return redirect()->route('coi_ao.show', $transaction->id);
    }
    public function destroy($id) {
        $transaction = Transaction::find($id);
        $transaction->status = 'deleted';
        if($transaction->save()) session(['success' => 'Record deleted successfully']);
        else session(['error', 'Error on deleting the record']);
        return redirect()->route('coi_ao.index');
    }
    public function search(Request $request) {
        $transactions = DB::table('transaction')
            ->where('type', 'AO')
            ->where('status', '!=', 'deleted')
            ->where('userbranch', Branch::find(auth()->user()->branch_id)->branch_name)
            ->where(function($query) use ($request) {
                $query->where('coi_number', 'like', '%'.$request->search.'%')
                    ->orWhere('policy_number', 'like', '%'.$request->search.'%')
                    ->orWhere('insured_name', 'like', '%'.$request->search.'%');
            })
            ->orderBy('id', 'desc')
            ->paginate(15);
        $search = $request->search;
        $transactions->appends(['search' => $search]);
        return view('transactions.coi_ao.index', compact('search', 'transactions'));
    }
    public function post($id) {
        $transaction = Transaction::find($id);
        $transaction->posted = 1;
        if($transaction->save()) session(['success' => 'Record posted successfully']);
        else session(['error', 'Error on posting the record']);
        return redirect()->route('coi_ao.index');
    }
    public function print($id) {
        $transaction = Transaction::find($id);
        if($transaction->type == 'AO') {
            // $price = Insuran_price::find(1);
            $holder = array();
            $holder1 = 0;
            $holder2 = 0;
            $holder3 = 0;
            // ==============================
            //  Principal Sum & Unprovoked Murder
            // ==============================
                ### Principal sum###
            for ($i=0; $i < $transaction->units; $i++) { 
                $holder1 = $holder1 + 20000;
                $holder['principal_sum'] =  number_format($holder1,2);
            }$holder1 = 0;
                ### Unprovoked Murder ###
            for ($i=0; $i < $transaction->units; $i++) { 
                if ($i < 2) {
                    $holder2 = $holder2 + 20000;
                    $holder['unprovoked_murder'] =  number_format($holder2,2);
                }
            }$holder2 = 0;
            $view = \View::make('transactions/coi_ao.coi_ao-pdf', compact('transaction', 'holder'));
            $html_content = $view->render();
            PDF::SetTitle('COI AO');
            PDF::AddPage();
            PDF::SetFooterMargin(PDF_MARGIN_FOOTER);
            PDF::SetAutoPageBreak(TRUE, 0);
            PDF::Image("../public/images/a.png", 160, 83, 20);
            PDF::Image("../public/images/logo.png", 107, 12, 20);
            PDF::Image("../public/images/ml_logo.png", 15, 12, 48);
            PDF::writeHTML($html_content, true, false, true, false, '');
        } else {
            PDF::AddPage("P", "A4");
            PDF::writeHTML('<h3>Invalid record</h3>', true, false, true, false, '');
        }
        PDF::SetFont('Helvetica', '', 10);
        PDF::Output('COI AO.pdf');
    }
    // public function getCoiNumber() {
    //     $coi_number = DB::table('transaction')->where('status', '!=', 'deleted')->max('coi_number');
    //     return substr('0000000'.(intval($coi_number) + 1), -7);
    // }
}
