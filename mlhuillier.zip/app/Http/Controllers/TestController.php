<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Test;
  

class TestController extends Controller

{

    /**

     * Create a new controller instance.

     *

     * @return void

     */

    public function ajaxRequest()

    {

        return view('ajaxRequest');

    }

   

    /**

     * Create a new controller instance.

     *

     * @return void

     */

    public function ajaxRequestPost($id = 0)

    {
        $userData = Test::find($id);

        echo json_encode($userData);
        exit;
        // return Response::json($userData);
        // $input = $request->all();
        // return response()->json(['success'=>'Got Simple Ajax Request.']);

    }

}

