<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Transaction;
use DB;
class AllTransactionsController extends Controller {
    public function index() {
        $transactions = Transaction::orderBy('id', 'desc')
            ->paginate(30);
        return view('reports.all.index', compact('transactions'));
    }
    public function create() { }
    public function store(Request $request) { }
    public function show($id) {
        $transaction = Transaction::find($id);
        return view('reports.all.show', compact('transaction'));
    }
    public function edit($id) { }
    public function update(Request $request, $id) { }
    public function destroy($id) { }
    public function search(Request $request) {
        // $transactions = DB::table('transaction')
        $transactions = Transaction::where(function($query) use ($request) {
            $query->where('coi_number', 'like', '%'.$request->search.'%')
                ->orWhere('ticket_number', 'like', '%'.$request->search.'%')
                ->orWhere('insured_name', 'like', '%'.$request->search.'%')
                ->orWhere('type', 'like', '%'.$request->search.'%')
                ->orWhere('userbranch', 'like', '%'.$request->search.'%')
                ->orWhere('status', strtoupper($request->search) == 'ACTIVE' ? 'active' : (strtoupper($request->search) == 'DELETED' ? 'deleted' : ''))
                ->orWhere('posted', strtoupper($request->search) == 'POSTED' ? '1`' : (strtoupper($request->search) == 'UNPOSTED' ? null : ''))
            ;})
            ->orderBy('id', 'desc')
            ->paginate(30);
        $search = $request->search;
        $transactions->appends(['search' => $search]);
        return view('reports.all.index', compact('search', 'transactions'));
    }
    public function filter(Request $request) {
        $request->validate([
            'date_from' => 'required',
            'date_to' => 'required',
        ]);
        $transactions = Transaction::where(function($query) use ($request) {
            $query->whereBetween('date_issued', [$request->date_from, $request->date_to])
            ;})
            ->orderBy('id', 'desc')
            ->paginate(30);
        $date_from = $request->date_from;
        $date_to = $request->date_to;
        $transactions->appends([
            'date_from' => $date_from,
            'date_to' => $date_to,
        ]);
        return view('reports.all.index', compact('date_from', 'date_to', 'transactions'));
    }
}
