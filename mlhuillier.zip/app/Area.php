<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
class Area extends Model {
    protected $table = 'areas';
    public $primarykey = 'id';
    public $timestamps = true;
    public function branches() {
        return $this->hasMany(Branch::class);
    }
    public function region() {
        return $this->belongsTo(Region::class);
    }
}
