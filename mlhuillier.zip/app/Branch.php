<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
class Branch extends Model {
    protected $table = 'branches';
    public $primarykey = 'id';
    public $timestamps = true;
    public function users() {
        return $this->hasMany(User::class);
    }
    // public function transaction() {
    //     return $this->belongsTo('App\Transaction');
    // }
    public function area() {
        return $this->belongsTo(Area::class);
    }
}
