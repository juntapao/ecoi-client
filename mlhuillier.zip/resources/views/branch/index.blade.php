@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">List of Branches</div>

                <div class="panel-body">
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-primary" id="adds" title="Add a new record" data-tooltip>
                        Add
                    </button>

                    <!-- Table -->
                    <div class="sub panel-body">
                        <table id="branch" class="table table-hover table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Branch Name</th>
                                    <th>Role</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            
                            <tbody>
                                @if (count($branch)>0)
                                    @foreach ($branch as $branchs)
                                        <tr>
                                            <td>{{$branchs->branch_name}}</td>
                                            <td>{{$branchs->code}}</td>
                                            <td>
                                               <!--  <form method="POST" action="">  -->
                                                    <a href="branch/{{$branchs->id}}/edit" class="btn btn-warning" >Edit</a>  
                                                    
                                                <!-- </form>  -->
                                                
                                            </td>
                                        </tr>
                                    @endforeach
                                @else
                                    <p>No branch found</p>
                                @endif
                            </tbody>

                        </table>
                    </div>

                    <!-- Add Modal -->
                    <div class="modal fade" id="add" name="add" tabindex="-1" role="dialog" aria-labelledby="addTitle" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <div class="row">
                                        <div class="col-md-8"><h5 class="modal-title" id="exampleModalLongTitle"></h5></div>
                                        <div class="col-md-4"><button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button></div>
                                    </div>
                                </div>
                                <form  method="POST" action="{{url("branch")}}">
                                        {{csrf_field()}}
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="form-group col-md-6">
                                                <label for="inputEmail4">Branch Name</label>
                                                <input type="text" id="branch_name" name="branch_name" class="form-control" id="inputEmail4" placeholder="Branch Name" required>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="inputPassword4">Code</label>
                                                <input type="text" id="code" name="code" class="form-control" id="inputPassword4" placeholder="Code" required>
                                            </div>
                                        </div> 
                                    </div>
                                    <input type="hidden" id="id" name="id" />
                                    <input type="hidden" id="command" name="command" />

                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-success">Save</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
    
                    

                </div>
            </div>
        </div>
    </div>
</div>

    
@endsection