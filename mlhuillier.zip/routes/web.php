<?php
// use App\Exports\Detailed;
// use Maatwebsite\Excel\Facades\Excel;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// Route::get('/', function () {
//     return view('auth.login');
//     // return view('login');
//     // return redirect()->route('login');
// });
Route::get('/', 'Auth\LoginController@showLoginForm');

//Route::get('create_user', function () {
//    return view('pages.create_user');
//});


// Route::get('/clear-cache', function() {
//     // Artisan::call('cache:clear');
//     return "Cache is cleared";
// });


Auth::routes();
Route::post('login/custom',[
    'uses' => 'Auth\LoginController@login',
    'as' => 'login.custom'
]);

// Route::get('layouts', 'NavController@index')->name('layouts.app');
//MAINTENANCE
// Route::resource('maintenance/branch', 'BranchController');
// Route::get('maintenance/branch/{branch}/edit_region', 'BranchController@edit_region');
// Route::get('maintenance/branch/{branch}/edit_area', 'BranchController@edit_area');
// Route::get('maintenance/branch/getArea/{id}', 'BranchController@getArea');
// Route::get('maintenance/branch/{branch}/getArea_edit/{id}', 'BranchController@getArea_edit');

//REGISTERED
// Route::resource('registered', 'RegisteredController');
Route::middleware(['auth'])->group(function() {
    //TRANSACTION
    Route::prefix('maintenance')->group(function() {
        // USERS
        Route::get('users/search', 'UserController@search')->name('users.search');
        Route::resource('users', 'UserController');
        // ROLES
        Route::get('roles/search', 'RolesController@search')->name('roles.search');
        Route::resource('roles', 'RolesController');
        // BRANCHES
        Route::get('branch/search', 'BranchController@search')->name('branch.search');
        Route::resource('branch', 'BranchController');
        // REGIONS
        Route::get('region/search', 'RegionController@search')->name('region.search');
        Route::resource('region', 'RegionController');
        // AREAS
        Route::get('area/search', 'AreaController@search')->name('area.search');
        Route::resource('area', 'AreaController');
        // OTHERS
        // Route::resource('insurance_price', 'InsurancePriceController')->except(['create', 'store', 'destroy']);
        Route::resource('change_password', 'ChangePasswordController')->only(['edit', 'update']);
    });
    Route::prefix('transactions')->group(function() {
        // COI A
        Route::prefix('coi_a')->group(function() {
            Route::get('search', 'CoiAController@search')->name('coi_a.search');
            Route::get('print/{coi_a}', 'CoiAController@print')->name('coi_a.print');
            Route::get('post/{coi_a}', 'CoiAController@post')->name('coi_a.post');
        });
        Route::resource('coi_a', 'CoiAController');
        // COI AO
        Route::prefix('coi_ao')->group(function() {
            Route::get('search', 'CoiAOController@search')->name('coi_ao.search');
            Route::get('print/{coi_ao}', 'CoiAOController@print')->name('coi_ao.print');
            Route::get('post/{coi_ao}', 'CoiAOController@post')->name('coi_ao.post');
        });
        Route::resource('coi_ao', 'CoiAOController');
        // COI B
        Route::prefix('coi_b')->group(function() {
            Route::get('search', 'CoiBController@search')->name('coi_b.search');
            Route::get('print/{coi_b}', 'CoiBController@print')->name('coi_b.print');
            Route::get('post/{coi_b}', 'CoiBController@post')->name('coi_b.post');
        });
        Route::resource('coi_b', 'CoiBController');
        // COI D
        Route::prefix('coi_d')->group(function() {
            Route::get('search', 'CoiDController@search')->name('coi_d.search');
            Route::get('print/{coi_d}', 'CoiDController@print')->name('coi_d.print');
            Route::get('post/{coi_d}', 'CoiDController@post')->name('coi_d.post');
        });
        Route::resource('coi_d', 'CoiDController');
        // COI D
        Route::prefix('coi_r')->group(function() {
            Route::get('search', 'CoiRController@search')->name('coi_r.search');
            Route::get('print/{coi_r}', 'CoiRController@print')->name('coi_r.print');
            Route::get('post/{coi_r}', 'CoiRController@post')->name('coi_r.post');
        });
        Route::resource('coi_r', 'CoiRController');
    });
    Route::prefix('reports')->group(function() {
        // POSTED TRANSACTIONS
        Route::get('posted/search', 'PostedController@search')->name('posted.search');
        Route::get('posted/filter', 'PostedController@filter')->name('posted.filter');
        Route::get('posted/extract', 'PostedController@extract')->name('posted.extract');
        Route::resource('posted', 'PostedController')->only(['index', 'show']);
        // REPORTS
        Route::resource('detailed', 'DetailedController')->only(['index', 'store']);
        Route::resource('summary', 'SummaryController')->only(['index', 'store']);
        // ALL TRANSACTIONS
        Route::get('all/search', 'AllTransactionsController@search')->name('all.search');
        Route::get('all/filter', 'AllTransactionsController@filter')->name('all.filter');
        Route::resource('all', 'AllTransactionsController')->only(['index', 'show']);
    });
    Route::get('/dashboard', 'DashboardController@index')->name('dashboard');
});

// Route::get('reports/detailed', function (){
//     return Excel::download(new Detailed, 'detailed_report.xlsx');
// });

// Route::post('/create', 'UserController@create');
//Route::get('coi_a-report/{id}', 'CoiAController@report')->name('coi_a-report.report');
//Route::get('coi_a-report/{id}', 'CoiAController@show')->name('coi_a-report');

// Route::get('ajaxRequest', 'TestController@ajaxRequest');
// Route::post('ajaxRequest','TestController@ajaxRequestPost');
// Route::get('ajaxRequest', 'TestController@ajaxRequest');
// Route::get('ajaxRequestPost/{id}','TestController@ajaxRequestPost');
